const form = document.getElementById('newsletter-form');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const email = document.getElementById('email').value;

  if (!email) {
    alert('Please add an email address.');
    return;
  }

  // Save the email to Local Storage
  localStorage.setItem('userEmail', email);

  // Create a new div element
  const newDiv = document.createElement('div');
  newDiv.textContent = 'Space X First Space Orginization to "Catch" an Orbital Rockect Booster (Oct 13, 24): Read this story';
  newDiv.style.cursor = 'pointer';
  newDiv.style.marginTop = '10px'; // Add margin-top to create space below the email input

  // Add a click event listener to the new div
  newDiv.addEventListener('click', () => {
    // Redirect to the second page URL
    window.location.href = 'articales/Article1/articale1.html';
  });

  // Append the new div to the form
  form.appendChild(newDiv);

  // Clear the form field
  document.getElementById('email').value = '';

});