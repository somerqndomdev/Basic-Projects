// checkSavedEmail.js
window.onload = function() {
    const savedEmail = localStorage.getItem('userEmail');
  
    if (savedEmail) {
      console.log(`Welcome back, ${savedEmail}!`);
      
      document.getElementById('email').value = localStorage.getItem('userEmail')

      // You can do more here, like displaying a personalized message or redirecting to a specific page.

    } else {
      alert("No saved email found... To make one type it bellow");
    }
  };